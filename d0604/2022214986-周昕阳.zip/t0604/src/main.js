import { createApp } from 'vue'
// import './style.css' 
import Student from './Student.vue'

createApp(Student).mount('#app')
