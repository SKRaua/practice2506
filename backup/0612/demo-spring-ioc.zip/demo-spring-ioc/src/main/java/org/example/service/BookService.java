package org.example.service;

public interface BookService {
    void writeBook();
}
