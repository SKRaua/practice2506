package org.example.service;

public interface UserService {
    void knowName();
}
