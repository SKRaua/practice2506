package org.example.dao;

public interface UserDAO {
    void getName();
}
