package org.example.dao;

public interface PersonDAO {
    public void eat();
}
