package org.example.dao;

public interface BookDAO {
    void readBook();
}
